<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>PatitasHogar</title>

    @vite(['resources/css/app.css','resources/js/app.js'])
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">

    <div class="container">

        <a class="navbar-brand" href="/">
            🐶 PatitasHogar
        </a>

        <div class="ms-auto">

            @auth

                <span class="text-white me-3">
                    {{ auth()->user()->name }}
                </span>

                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                    @csrf
                    <button class="btn btn-light btn-sm">
                        Cerrar sesión
                    </button>
                </form>

            @endauth

        </div>

    </div>

</nav>

<div class="container mt-4">

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    @yield('content')

</div>

</body>
</html>