<h1>Solicitudes</h1>

@foreach($requests as $request)

<div class="card mb-3">

    <div class="card-body">

        <h4>Mascota: {{ $request->pet->name }}</h4>

        <p><strong>Solicitante:</strong> {{ $request->adopter->name }}</p>

        <p><strong>Motivo:</strong> {{ $request->reason }}</p>

        <p><strong>Estado:</strong> {{ $request->status }}</p>

        @if($request->status == 'pending')

            <form method="POST"
                  action="{{ route('admin.adoptions.approve', $request) }}"
                  class="d-inline">

                @csrf

                <button class="btn btn-success">
                    Aprobar
                </button>

            </form>

            <form method="POST"
                  action="{{ route('admin.adoptions.reject', $request) }}"
                  class="d-inline">

                @csrf

                <button class="btn btn-danger">
                    Rechazar
                </button>

            </form>

        @endif

        @if($request->status == 'approved')

            <a href="{{ route('followups.history', $request->pet) }}"
               class="btn btn-info">
                Ver seguimientos
            </a>

        @endif

    </div>

</div>

@endforeach