<!DOCTYPE html>
<html>
<head>
    <title>Crear Mascota</title>
</head>

<body>

<h1>Registrar Mascota</h1>


<form action="{{ route('pets.store') }}" method="POST">

@csrf


<label>
Nombre:
</label>

<br>

<input type="text" name="name" required>

<br><br>


<label>
Especie:
</label>

<br>

<select name="species_id" required>

@foreach($species as $item)

<option value="{{ $item->id }}">
{{ $item->name }}
</option>

@endforeach

</select>


<br><br>


<label>
Raza:
</label>

<br>

<input type="text" name="breed" required>


<br><br>


<label>
Edad (meses):
</label>

<br>

<input type="number" name="age_months" required>


<br><br>


<label>
Tamaño:
</label>

<br>

<select name="size">

<option value="small">
Pequeño
</option>

<option value="medium">
Mediano
</option>

<option value="large">
Grande
</option>

</select>


<br><br>


<label>
Descripción:
</label>

<br>

<textarea name="description"></textarea>


<br><br>


<button type="submit">
Guardar mascota
</button>


</form>


<br>

<a href="{{ route('pets.index') }}">
Volver
</a>


</body>
</html>