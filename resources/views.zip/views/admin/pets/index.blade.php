@extends('layouts.app')

@section('content')

<div class="container">

    <h1 class="mb-4">Gestión de Mascotas</h1>

    <a href="{{ route('pets.create') }}" class="btn btn-success mb-3">
        Nueva mascota
    </a>

    <table class="table table-bordered table-hover align-middle">

        <thead class="table-success">

            <tr>
                <th>Nombre</th>
                <th>Especie</th>
                <th>Raza</th>
                <th>Estado</th>
                <th width="250">Acciones</th>
            </tr>

        </thead>

        <tbody>

        @forelse($pets as $pet)

            <tr>

                <td>{{ $pet->name }}</td>

                <td>{{ $pet->species->name }}</td>

                <td>{{ $pet->breed }}</td>

                <td>

                    @if($pet->status == 'available')
                        <span class="badge bg-success">Disponible</span>

                    @elseif($pet->status == 'in_process')
                        <span class="badge bg-warning text-dark">En proceso</span>

                    @elseif($pet->status == 'adopted')
                        <span class="badge bg-primary">Adoptada</span>
                    @endif

                </td>

                <td>

                    <a href="{{ route('pets.edit', $pet) }}"
                       class="btn btn-warning btn-sm">
                        Editar
                    </a>

                    @if($pet->status == 'adopted')

                        <a href="{{ route('followups.history', $pet) }}"
                           class="btn btn-info btn-sm">
                            Historial
                        </a>

                    @endif

                    <form action="{{ route('pets.destroy', $pet) }}"
                          method="POST"
                          class="d-inline">

                        @csrf
                        @method('DELETE')

                        <button class="btn btn-danger btn-sm"
                                onclick="return confirm('¿Eliminar esta mascota?')">
                            Eliminar
                        </button>

                    </form>

                </td>

            </tr>

        @empty

            <tr>

                <td colspan="5" class="text-center">
                    No hay mascotas registradas.
                </td>

            </tr>

        @endforelse

        </tbody>

    </table>

</div>

@endsection