<h1>Especies</h1>

<a href="{{route('species.create')}}">
Nueva especie
</a>


@foreach($species as $item)

<p>
{{$item->name}}

<form method="POST"
action="{{route('species.destroy',$item)}}">

@csrf
@method('DELETE')

<button>
Eliminar
</button>

</form>

</p>

@endforeach