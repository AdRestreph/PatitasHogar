<h1>Nueva especie</h1>


<form method="POST"
action="{{route('species.store')}}">

@csrf

<input 
name="name"
placeholder="Nombre">


<button>
Guardar
</button>

</form>