@extends('layouts.app')

@section('content')

<div class="container">

    <h2 class="mb-4">
        Historial de seguimiento
    </h2>

    <div class="card mb-4">

        <div class="card-body">

            <h3>{{ $pet->name }}</h3>

            <p>
                <strong>Especie:</strong>
                {{ $pet->species->name }}
            </p>

            <p>
                <strong>Estado:</strong>

                <span class="badge bg-primary">
                    {{ ucfirst($pet->status) }}
                </span>
            </p>

        </div>

    </div>

    @forelse($pet->adoptionRequests as $request)

        @foreach($request->followUps->sortBy('visit_date') as $follow)

            <div class="card mb-3 border-start border-5
                {{ $follow->pet_condition == 'good'
                    ? 'border-success'
                    : 'border-warning' }}">

                <div class="card-body">

                    <h5>
                        📅 {{ $follow->visit_date }}
                    </h5>

                    <p class="mb-2">

                        @if($follow->pet_condition == 'good')

                            <span class="badge bg-success">
                                Buena condición
                            </span>

                        @else

                            <span class="badge bg-warning text-dark">
                                Necesita atención
                            </span>

                        @endif

                    </p>

                    <p>{{ $follow->notes }}</p>

                </div>

            </div>

        @endforeach

    @empty

        <div class="alert alert-info">
            Esta mascota aún no tiene seguimientos registrados.
        </div>

    @endforelse

    <a href="{{ route('pets.index') }}" class="btn btn-secondary mt-3">
        Volver
    </a>

</div>

@endsection