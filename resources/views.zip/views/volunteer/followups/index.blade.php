@extends('layouts.app')

@section('content')

<h1>Adopciones aprobadas</h1>

<table class="table table-bordered">

    <tr>
        <th>Mascota</th>
        <th>Adoptante</th>
        <th></th>
    </tr>

    @foreach($requests as $request)

    <tr>

        <td>{{ $request->pet->name }}</td>

        <td>{{ $request->adopter->name }}</td>

        <td>

            <a
            class="btn btn-primary"
            href="{{ route('followups.create',$request) }}">

                Registrar visita

            </a>

        </td>

    </tr>

    @endforeach

</table>

@endsection