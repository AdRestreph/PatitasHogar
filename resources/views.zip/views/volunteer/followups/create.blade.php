@extends('layouts.app')

@section('content')

<h2>Seguimiento de {{ $adoptionRequest->pet->name }}</h2>

<form method="POST"
action="{{ route('followups.store',$adoptionRequest) }}">

@csrf

<div class="mb-3">

<label>Fecha</label>

<input
type="date"
name="visit_date"
class="form-control">

</div>

<div class="mb-3">

<label>Notas</label>

<textarea
name="notes"
class="form-control">
</textarea>

</div>

<div class="mb-3">

<label>Condición</label>

<select
name="pet_condition"
class="form-control">

<option value="good">
Buena
</option>

<option value="needs_attention">
Necesita atención
</option>

</select>

</div>

<button class="btn btn-success">

Guardar seguimiento

</button>

</form>

@endsection