<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>{{ $pet->name }}</title>
</head>
<body>

<h1>{{ $pet->name }}</h1>

<p><strong>Especie:</strong> {{ $pet->species->name }}</p>

<p><strong>Raza:</strong> {{ $pet->breed }}</p>

<p><strong>Edad:</strong> {{ $pet->age_months }} meses</p>

<p><strong>Tamaño:</strong> {{ ucfirst($pet->size) }}</p>

<p><strong>Estado:</strong> {{ $pet->status }}</p>

<p><strong>Descripción:</strong></p>
<p>{{ $pet->description }}</p>

<hr>

<h2>Solicitar adopción</h2>

<form method="POST" action="{{ route('adoption.store', $pet) }}">
    @csrf

    <div>
        <label>¿Por qué quieres adoptar esta mascota?</label><br>
        <textarea name="reason" rows="4" cols="50" required></textarea>
    </div>

    <br>

    <div>
        <label>Tipo de vivienda</label><br>
        <input type="text" name="home_type" required>
    </div>

    <br>

    <div>
        <label>¿Tienes otras mascotas?</label><br>

        <select name="has_other_pets">
            <option value="0">No</option>
            <option value="1">Sí</option>
        </select>
    </div>

    <br>

    <button type="submit">
        Enviar solicitud
    </button>

</form>

<br>

<a href="{{ route('adopter.pets') }}">
    ← Volver al catálogo
</a>

</body>
</html>