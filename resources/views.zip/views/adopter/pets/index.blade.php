<h1>Mascotas disponibles</h1>


@foreach($pets as $pet)

<div>

<h3>
{{ $pet->name }}
</h3>

<p>
Especie:
{{ $pet->species->name }}
</p>

<p>
Raza:
{{ $pet->breed }}
</p>


<a href="{{route('adopter.pet.show',$pet)}}">
Ver detalle
</a>


</div>

<hr>


@endforeach