@extends('layouts.app')

@section('content')

<div class="container">

    <h1 class="mb-4">Mis solicitudes de adopción</h1>

    @if(session('success'))

        <div class="alert alert-success">
            {{ session('success') }}
        </div>

    @endif

    @if($requests->isEmpty())

        <div class="alert alert-info">
            Aún no has realizado solicitudes de adopción.
        </div>

    @else

        <table class="table table-bordered table-hover align-middle">

            <thead class="table-success">

                <tr>
                    <th>Mascota</th>
                    <th>Estado</th>
                    <th>Motivo</th>
                    <th>Tipo de vivienda</th>
                </tr>

            </thead>

            <tbody>

            @foreach($requests as $request)

                <tr>

                    <td>
                        {{ $request->pet->name }}
                    </td>

                    <td>

                        @if($request->status == 'pending')

                            <span class="badge bg-warning text-dark">
                                Pendiente
                            </span>

                        @elseif($request->status == 'approved')

                            <span class="badge bg-success">
                                Aprobada
                            </span>

                        @else

                            <span class="badge bg-danger">
                                Rechazada
                            </span>

                        @endif

                    </td>

                    <td>
                        {{ $request->reason }}
                    </td>

                    <td>
                        {{ ucfirst($request->home_type) }}
                    </td>

                </tr>

            @endforeach

            </tbody>

        </table>

    @endif

</div>

@endsection